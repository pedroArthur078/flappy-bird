let bird;
let pipes = [];
let score = 0;
let gravity = 0.5;
let lift = -10;
let pipeWidth = 60;
let gap = 150;
let pipeVelocity = -6;
let level = 1;
let levelUpScore = 5;
let gameStarted = false; // Variável para controlar o estado do jogo (início ou em andamento)

function setup() {
  createCanvas(400, 600);
  bird = new Bird();
}

function draw() {
  if (!gameStarted) {
    // Tela inicial
    background(255);
    textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    text("Jogo do Passarinho", width / 2, height / 3);
    textSize(24);
    text("Pressione qualquer tecla para começar", width / 2, height / 2);
    return; // Não faz mais nada no draw enquanto o jogo não começar
  }

  background(255);

  // Atualizar e desenhar o pássaro
  bird.update();
  bird.display();

  // Criar e desenhar os obstáculos
  if (pipes.length === 0 || pipes[pipes.length - 1].x < width - 200) {
    pipes.push(new Pipe());
  }

  for (let i = pipes.length - 1; i >= 0; i--) {
    pipes[i].update();
    pipes[i].display();

    // Verifica se o tubo saiu da tela
    if (pipes[i].x + pipeWidth < 0) {
      pipes.splice(i, 1); // Remove o tubo
      score += 1;
    }

    // Checar colisão
    if (bird.collidesWith(pipes[i])) {
      gameOver();
      return;
    }
  }

  // Verificar se o jogador passou para o próximo nível
  if (score >= level * levelUpScore) {
    levelUp();
  }

  // Exibir o score e o nível
  fill(0);
  textSize(32);
  text(`Score: ${score}`, 10, 30);
  textSize(24);
  text(`Level: ${level}`, 10, 60);
}

function keyPressed() {
  if (!gameStarted) {
    gameStarted = true; // Inicia o jogo
    loop(); // Inicia o loop do jogo
    return; // Impede que o código abaixo execute se o jogo não tiver começado
  }

  if (key === ' ') {
    bird.jump();
  }
  if (key === 'r' || key === 'R') {
    resetGame();  // Reinicia o jogo
  }
}

// Classe do passarinho
class Bird {
  constructor() {
    this.x = 50;
    this.y = height / 2;
    this.velY = 0;
  }

  update() {
    this.velY += gravity; // Aplicar gravidade
    this.y += this.velY;

    // Evitar que o pássaro saia da tela
    if (this.y < 0) this.y = 0;
    if (this.y > height - 40) this.y = height - 40; // Limitar o pássaro a não sair para baixo
  }

  jump() {
    this.velY = lift; // Pulo
  }

  display() {
    fill(0, 0, 255);
    noStroke();
    ellipse(this.x, this.y, 40, 40); // Desenho do pássaro
  }

  collidesWith(pipe) {
    // Verifica colisão com os tubos
    if (this.x + 20 > pipe.x && this.x - 20 < pipe.x + pipeWidth) {
      if (this.y - 20 < pipe.height || this.y + 20 > pipe.height + gap) {
        return true;
      }
    }
    return false;
  }
}

// Classe dos obstáculos (tubos)
class Pipe {
  constructor() {
    this.x = width;
    this.height = random(100, 400); // Altura do tubo
  }

  update() {
    this.x += pipeVelocity; // Move o tubo para a esquerda
  }

  display() {
    fill(0, 255, 0);
    noStroke();
    rect(this.x, 0, pipeWidth, this.height); // Tubo superior
    rect(this.x, this.height + gap, pipeWidth, height - (this.height + gap)); // Tubo inferior
  }
}

// Função de Game Over
function gameOver() {
  background(255);
  textSize(48);
  fill(0);
  textAlign(CENTER, CENTER);
  text("GAME OVER", width / 2, height / 3);
  textSize(32);
  text(`Score: ${score}`, width / 2, height / 2);
  textSize(24);
  text("Pressione 'R' para reiniciar", width / 2, height / 1.5);
  noLoop(); // Pausa o jogo
}

// Função para reiniciar o jogo
function resetGame() {
  bird = new Bird();
  pipes = [];
  score = 0;
  level = 1; // Reseta o nível
  gameStarted = false; // Volta para a tela inicial
  loop(); // Retorna o loop de animação
}

// Função para aumentar o nível
function levelUp() {
  level++; // Aumenta o nível
  pipeVelocity -= 1; // Aumenta a velocidade dos tubos
  gap -= 10; // Diminui o espaço entre os tubos (opcional)
  levelUpScore += 5; // Aumenta a pontuação necessária para o próximo nível
}
